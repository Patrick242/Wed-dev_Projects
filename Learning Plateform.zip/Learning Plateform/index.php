<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="index.css"/>
	<title>Mere Milla Academy</title>
</head>
   
   <div class="box">
<!--NAVIGATION-->
       <nav>
          <img src="image/logo.png" class="img" alt="logo"> 
          <ul>
              <li><a href="#">HOME</a></li>
              <li><a href="#">ABOUT</a></li>
              <li><a href="#">COURSES</a></li>
              <li><a href="#">LEARNERS</a></li>
              <li><a href="#">TEACHERS</a></li>
              <li><a href="#">PARENTS</a></li>
              <li><a href="#">APPLY</a></li>
              <li><a href="#">PAGES</a></li>
              
          </ul>
       </nav>
<!--END OF NAVIGATION-->
      
      <div class="section">
          <h1>WE ENSURE A BETTER EDUCATION <br> FOR A BETTER WORLD</h1>
          
          <a href="#"><button class="btn-1">GET STARTED</button></a>
<!--FEATURES-->
         <div class="features">
             <button>Learn Online Classes</button>
             <button>Bridge Courses</button>
             <button>Huge Library</button>
             <button>Practical Exposure</button>
         </div>
<!--END OF FEATURES-->
      </div>
<!--END OF SECTION-->
   </div>
<!--END OF WRAPPER-->
   
<!--SHOWCASE-->
   <div class="show">
       <h1>POPULAR COURSES WE OFFER</h1>
       <div id="courses">
           <div class="MT">
               <h3>Mathematique</h3>
               <img src="image/math.jpg" width="50%" alt="Math">
               <a href="#" ><button class="Join">Join Class</button></a>
           </div>
           <div class="pc">
               <h3>Physics</h3>
               <img src="image/physic.jpg" alt="physic">
               <a href="#" ><button class="Join">Join Class</button></a>
           </div>
           <div class="hs">
               <h3>History</h3>
               <img src="image/history.png" alt="history">
               <a href="#" ><button class="Join">Join Class</button></a>
           </div>
           <div class="cm">
               <h3>Chemical</h3>
               <img src="image/chemical.jpg" alt="chemical">
               <a href="#" ><button class="Join">Join Class</button></a>
           </div>
           <div class="bl">
               <h3>Biology</h3>
               <img src="image/biology.jpg" alt="bl">
               <a href="#" ><button class="Join">Join Class</button></a>
           </div>
       </div>
   </div>
<!--END OF SHOWCASE-->
   
   <footer>
       <p>Copyright &copy; 2020, Mere Milla Academy</p>
   </footer>
    
</body>
</html>